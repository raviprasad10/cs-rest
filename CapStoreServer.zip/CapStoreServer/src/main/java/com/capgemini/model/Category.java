package com.capgemini.model;

public class Category {
	
}
