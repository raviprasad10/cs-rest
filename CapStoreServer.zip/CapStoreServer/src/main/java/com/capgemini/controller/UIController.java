package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.model.Merchant;
import com.capgemini.service.MerchantServiceImpl;

@Controller
public class UIController {
	
	@Autowired
	MerchantServiceImpl user;
	
	@RequestMapping(value="/")
	public String getIndexPage() {
		return user.index_page();
		
		//return "indexPage";	
	}
	
	@RequestMapping(value="SignIn")
	public String getSignInPage() {
		return user.signin_page();	
	}
	
	@ModelAttribute
	public Merchant getNewMerchant() { 
		return new Merchant();
	}
	
	@RequestMapping(value="/login")
	public String getLogInPage() {
		return user.login_page();	
	}
	
	@RequestMapping(value="/homePage")
	public String getHomePage() {
		return user.home_page();	
	}
}
