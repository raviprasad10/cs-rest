package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.model.Merchant;
import com.capgemini.service.IMerchantService;

@Controller
public class MerchantController {
	
	@Autowired
	IMerchantService MerchantServices;
	
	@RequestMapping(value = "merchantSignIn")
	public ModelAndView addMerchant(@ModelAttribute("merchant") Merchant merchant) {
	
		merchant = MerchantServices.addMerchant(merchant);
		return new ModelAndView("homePage");
	}
	
}
