package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.model.Merchant;
import com.capgemini.repository.IMerchantRepo;
@Component("MerchantServices")
public class MerchantServiceImpl implements IMerchantService {

	@Autowired(required = true)
	IMerchantRepo repo;
	
	@Override
	public Merchant addMerchant(Merchant merchant) {
	
		return repo.save(merchant);
	}

	
	public String index_page() {
		
		return "indexPage";
	}
	
public String signin_page() {
		
	return "SignIn";
	}
	
public String login_page() {
	
	return "login";
	}

public String home_page() {
	
	return "homePage";
	}
	
}
